
$tellraw $(player) $(json)

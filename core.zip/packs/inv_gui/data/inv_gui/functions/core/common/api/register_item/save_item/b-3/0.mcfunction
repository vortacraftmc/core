#> inv_gui:core/common/api/register_item/save_item/b-3/0
# @within function inv_gui:core/common/api/register_item/save_item/b-2/0

execute if score $TargetSlot inv_gui matches 0..1 run function inv_gui:core/common/api/register_item/save_item/b-4/0
execute if score $TargetSlot inv_gui matches 2..3 run function inv_gui:core/common/api/register_item/save_item/b-4/1
